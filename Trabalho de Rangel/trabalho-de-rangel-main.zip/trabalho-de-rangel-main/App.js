import React from 'react';
import ParentComponent from './components/ParentComponent';

const App = () => {
  return <ParentComponent />;
};

export default App;
